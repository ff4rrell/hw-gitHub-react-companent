import React from 'react';

const Footer = () => (
    <footer className='footer'>
        footer
    </footer>
)


export default Footer;