import React from 'react';

const MainHeader = () => (
    <div className='main__header'>
        <h1>Learn Git and GitHub without any code!</h1>
        <h2>Using the Hello World guide, you'll a branch, write comments, and open a pull request</h2>
        <button className='main__green__button'>Read the guide</button>
    </div>
)

export default MainHeader;