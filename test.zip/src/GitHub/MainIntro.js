import React from 'react';

const MainIntro = () => (
    <div className='main__intro'>
        main__intro
    </div>
);

export default MainIntro;