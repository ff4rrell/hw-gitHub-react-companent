import React from 'react';

const Header = () => (
    <header className='header'>
        <button className='logo__button' >GitHub</button>
        <input type='text' id='logo__input'/>
        <ul>
            <li ><a href='#' className='header__link'>Pull Requests</a></li>&nbsp;
            <li ><a href='#' className='header__link'>Isues</a></li>&nbsp;
            <li ><a href='#' className='header__link'>Marketlace</a></li>&nbsp;
            <li ><a href='#' className='header__link'>Explore</a></li>&nbsp;
        </ul>
    </header>
)
export default Header;