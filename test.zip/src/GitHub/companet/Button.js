import React from 'react';



const Button = ({clildren}) => (
    <button className='button'>
        {clildren}
    </button>
);

export default Button;