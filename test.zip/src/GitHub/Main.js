import React from 'react';
import '../App.css';
import Button from './companet/Button';
import MainHeader from './MainHeader'
import MainIntro from './MainIntro'

const array = [];

const Main = () => (
    <main className='main'>
        <MainHeader/>
        <MainIntro/>
    </main>
)

export default Main;
